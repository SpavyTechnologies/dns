pushd `dirname "$0"` > /dev/null 2>&1

source venv/bin/activate

shopt -s expand_aliases

export PYTHONDONTWRITEBYTECODE="1"
export LC_ALL="C.UTF-8"
export LANG="C.UTF-8"

if [ -z "$1" ]; then
    RESULT=`supervisorctl pid dns-sensor 2> /dev/null`
    if [ "$RESULT" == 0 ] || [ -z "$RESULT" ]; then
	RESULT=`find /var/run/screen -name "*.dns-sensor" | wc -l | xargs`
	if [ "$RESULT" == 0 ]; then
	    screen -dmS dns-sensor python dns.py daemon/sensor
	else
	    echo "Error: dns-sensor is already running in a screen"
	fi
    else
	echo "Error: dns-sensor is already running from supervisor"
    fi
    RESULT=`supervisorctl pid dns-syncfw 2> /dev/null`
    if [ "$RESULT" == 0 ] || [ -z "$RESULT" ]; then
	RESULT=`find /var/run/screen -name "*.dns-syncfw" | wc -l | xargs`
	if [ "$RESULT" == 0 ]; then
	    screen -dmS dns-syncfw python dns.py daemon/syncfw
	else
	    echo "Error: dns-syncfw is already running in a screen"
	fi
    else
	echo "Error: dns-syncfw is already running from supervisor"
    fi
    RESULT=`supervisorctl pid dns-webapp 2> /dev/null`
    if [ "$RESULT" == 0 ] || [ -z "$RESULT" ]; then
	RESULT=`find /var/run/screen -name "*.dns-webapp" | wc -l | xargs`
	if [ "$RESULT" == 0 ]; then
	    screen -dmS dns-webapp python dns.py webapp
	else
	    echo "Error: dns-webapp is already running in a screen"
	fi
    else
	echo "Error: dns-webapp is already running from supervisor"
    fi
else
    python dns.py "$1"
fi

popd > /dev/null 2>&1