import unittest

class default(unittest.TestCase):
        def test_example(self):
                self.seertEqual("TEST", "TEST")