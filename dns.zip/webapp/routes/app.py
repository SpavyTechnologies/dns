from types import MethodDescriptorType
from .. import conf, db, app
from flask import g, session, request, abort, redirect, make_response, render_template
from datetime import datetime
import json

@app.route("/app", methods=["GET"])
def controller_app_root():
    return redirect("/app/dashboard")

@app.route("/app/auth", methods=["GET", "POST"])
def controller_app_root():
    return redirect("/app/dashboard")

@app.route("app/dashboard", methods=["GET", "POST"])
def controller_app_dashboard():
    return render_template("dashboard.html")